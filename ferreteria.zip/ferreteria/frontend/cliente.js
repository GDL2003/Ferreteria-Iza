document.addEventListener('DOMContentLoaded', () => {
    const searchButton = document.getElementById('searchButton');
    const searchInput = document.getElementById('searchInput');
    const productsList = document.getElementById('productsList');

    searchButton.addEventListener('click', async () => {
        const query = searchInput.value;
        try {
            const response = await fetch(`http://localhost:3000/api/products/search/${query}`);
            const products = await response.json();
            displayProducts(products);
        } catch (error) {
            console.error('Error fetching products:', error);
        }
    });

    const displayProducts = (products) => {
        productsList.innerHTML = '';
        if (products.length === 0) {
            productsList.innerHTML = '<p>No se encontraron productos.</p>';
            return;
        }
        products.forEach(product => {
            const productCard = document.createElement('div');
            productCard.classList.add('product-card');
            productCard.innerHTML = `
                <img src="${product.image || 'https://via.placeholder.com/150'}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p>${product.description}</p>
                <p>Precio: $${product.price}</p>
                <p>Stock: ${product.quantity}</p>
                <button>Añadir al carrito</button>
            `;
            productsList.appendChild(productCard);
        });
    };

    // Initial fetch to display all products
    const fetchAllProducts = async () => {
        try {
            const response = await fetch('http://localhost:3000/api/products');
            const products = await response.json();
            displayProducts(products);
        } catch (error) {
            console.error('Error fetching products:', error);
        }
    };

    fetchAllProducts();
});
