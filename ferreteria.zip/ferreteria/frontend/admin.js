document.addEventListener('DOMContentLoaded', () => {
    const addProductForm = document.getElementById('addProductForm');
    const searchButton = document.getElementById('searchButton');
    const searchInput = document.getElementById('searchInput');
    const productsList = document.getElementById('productsList');
    const editProductForm = document.getElementById('editProductForm');
    const editForm = document.getElementById('editForm');
    const logoutButton = document.getElementById('logoutButton');

    const token = localStorage.getItem('token');

    // Añadir un nuevo producto
    addProductForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const name = document.getElementById('name').value;
        const description = document.getElementById('description').value;
        const price = document.getElementById('price').value;
        const quantity = document.getElementById('quantity').value;

        try {
            const response = await fetch('http://localhost:3000/api/products', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ name, description, price, quantity })
            });

            if (response.ok) {
                alert('Producto añadido exitosamente');
                addProductForm.reset();
                fetchProducts();
            } else {
                const data = await response.json();
                alert(data.error || 'Error al añadir producto');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error al añadir producto');
        }
    });

    // Buscar productos
    searchButton.addEventListener('click', async () => {
        const query = searchInput.value;
        try {
            const response = await fetch(`http://localhost:3000/api/products/search/${encodeURIComponent(query)}`);
            if (!response.ok) throw new Error('Error fetching products');
            const products = await response.json();
            displayProducts(products);
        } catch (error) {
            console.error('Error fetching products:', error);
        }
    });

    // Mostrar productos
    const displayProducts = (products) => {
        productsList.innerHTML = '';
        if (products.length === 0) {
            productsList.innerHTML = '<p>No se encontraron productos.</p>';
            return;
        }
        products.forEach(product => {
            const productCard = document.createElement('div');
            productCard.classList.add('product-card');
            productCard.innerHTML = `
                <h3>${product.name}</h3>
                <p>${product.description}</p>
                <p>Precio: $${product.price}</p>
                <p>Stock: ${product.quantity}</p>
                <button data-id="${product.id}" class="delete-button">Eliminar</button>
            `;
            productsList.appendChild(productCard);
        });

        // Asignar eventos a los botones de edición y eliminación
        document.querySelectorAll('.edit-button').forEach(button => {
            button.addEventListener('click', (event) => {
                const productId = event.target.getAttribute('data-id');
                showEditForm(productId);
            });
        });

        document.querySelectorAll('.delete-button').forEach(button => {
            button.addEventListener('click', async (event) => {
                const productId = event.target.getAttribute('data-id');
                await deleteProduct(productId);
            });
        });
    };

    // Mostrar el formulario de edición
    async function showEditForm(productId) {
        try {
            const response = await fetch(`http://localhost:3000/api/products/${productId}`, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Error fetching product details');
            }

            const product = await response.json();

            document.getElementById('editProductId').value = product.id;
            document.getElementById('editName').value = product.name;
            document.getElementById('editDescription').value = product.description;
            document.getElementById('editPrice').value = product.price;
            document.getElementById('editQuantity').value = product.quantity;

            editProductForm.style.display = 'block';

        } catch (error) {
            console.error('Error:', error);
            alert(error.message);
        }
    }

    // Actualizar un producto
    editForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const productId = document.getElementById('editProductId').value;
        const name = document.getElementById('editName').value;
        const description = document.getElementById('editDescription').value;
        const price = document.getElementById('editPrice').value;
        const quantity = document.getElementById('editQuantity').value;

        try {
            const response = await fetch(`http://localhost:3000/api/products/${productId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ name, description, price, quantity })
            });

            if (response.ok) {
                alert('Producto actualizado exitosamente');
                editProductForm.style.display = 'none';
                fetchProducts();
            } else {
                const data = await response.json();
                alert(data.error || 'Error al actualizar producto');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error al actualizar producto');
        }
    });

    // Eliminar un producto
    async function deleteProduct(productId) {
        try {
            const response = await fetch(`http://localhost:3000/api/products/${productId}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.ok) {
                alert('Producto eliminado exitosamente');
                fetchProducts();
            } else {
                const data = await response.json();
                alert(data.error || 'Error al eliminar producto');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error al eliminar producto');
        }
    }

    // Cerrar sesión
    logoutButton.addEventListener('click', () => {
        localStorage.removeItem('token');
        window.location.href = 'login.html';
    });

    // Obtener productos al cargar la página
    const fetchProducts = async () => {
        try {
            const response = await fetch('http://localhost:3000/api/products', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Error fetching products');
            }

            const products = await response.json();
            displayProducts(products);
        } catch (error) {
            console.error('Error fetching products:', error);
        }
    };

    fetchProducts();
});
