document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const addProductForm = document.getElementById('addProductForm');
    const loadProductsButton = document.getElementById('loadProducts');
    const searchButton = document.getElementById('searchButton');
    const searchInput = document.getElementById('searchInput');

    if (loginForm) {
        loginForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            try {
                const response = await fetch('http://localhost:3000/api/auth/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ username, password })
                });

                const data = await response.json();
                if (response.ok) {
                    localStorage.setItem('token', data.token);
                    localStorage.setItem('role', data.role); // Guardar el rol en localStorage
                    if (data.role === 'admin') {
                        window.location.href = 'admin.html';
                    } else {
                        window.location.href = 'client.html';
                    }
                } else {
                    alert(data.error);
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Login failed');
            }
        });
    }

    if (registerForm) {
        registerForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            const username = document.getElementById('register-username').value;
            const password = document.getElementById('register-password').value;
            const role = "client"; // Default role for new users
            try {
                const response = await fetch('http://localhost:3000/api/auth/register', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ username, password, role })
                });

                const data = await response.json();
                if (response.ok) {
                    alert('Registration successful');
                    window.location.href = 'login.html';
                } else {
                    alert(data.error);
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Registration failed');
            }
        });
    }

    if (addProductForm) {
        addProductForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            const name = document.getElementById('name').value;
            const description = document.getElementById('description').value;
            const price = document.getElementById('price').value;
            const quantity = document.getElementById('quantity').value;

            try {
                const token = localStorage.getItem('token');
                const response = await fetch('http://localhost:3000/api/products', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}` // Asegúrate de que el token esté en el formato correcto
                    },
                    body: JSON.stringify({ name, description, price, quantity })
                });

                const data = await response.json();
                if (response.ok) {
                    alert('Product added successfully');
                    window.location.reload();
                } else {
                    alert(data.error);
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Failed to add product');
            }
        });
    }

    if (searchButton) {
        searchButton.addEventListener('click', async () => {
            const name = searchInput.value;
            try {
                const token = localStorage.getItem('token');
                const response = await fetch(`http://localhost:3000/api/products/search/${name}`, {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                });

                const products = await response.json();
                const productsList = document.getElementById('productsList');
                productsList.innerHTML = '';
                products.forEach(product => {
                    const productDiv = document.createElement('div');
                    productDiv.classList.add('product');
                    productDiv.innerHTML = `
                        <h3>${product.name}</h3>
                        <p>${product.description}</p>
                        <p>Price: $${product.price}</p>
                        <p>Quantity: ${product.quantity}</p>
                    `;
                    productsList.appendChild(productDiv);
                });
            } catch (error) {
                console.error('Error:', error);
                alert('Failed to search products');
            }
        });
    }
});
