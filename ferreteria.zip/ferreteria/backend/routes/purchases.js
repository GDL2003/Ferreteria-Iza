const express = require('express');
const router = express.Router();
const authenticate = require('../middlewares/authenticate');
const { purchaseProduct } = require('../controllers/purchaseController');

router.post('/purchase', authenticate, purchaseProduct);

module.exports = router;
