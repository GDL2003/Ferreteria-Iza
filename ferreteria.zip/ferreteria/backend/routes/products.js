const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');

// Define las rutas para los productos
router.get('/', productController.getProducts);           // Obtener todos los productos
router.post('/', productController.addProduct);           // Añadir un producto
router.put('/:id', productController.updateProduct);      // Actualizar un producto
router.delete('/:id', productController.deleteProduct);   // Eliminar un producto
router.get('/search/:name', productController.searchProducts); // Buscar productos por nombre

module.exports = router;
