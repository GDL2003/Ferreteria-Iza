const pool = require('../db');

exports.purchaseProduct = async (req, res) => {
  const { productId, quantity } = req.body;
  try {
    const product = await pool.query('SELECT * FROM products WHERE id = $1', [productId]);
    if (product.rows.length === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }
    if (product.rows[0].quantity < quantity) {
      return res.status(400).json({ error: 'Insufficient quantity' });
    }
    await pool.query(
      'UPDATE products SET quantity = quantity - $1 WHERE id = $2',
      [quantity, productId]
    );
    res.json({ message: 'Purchase successful' });
  } catch (error) {
    console.error('Error during purchase:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
